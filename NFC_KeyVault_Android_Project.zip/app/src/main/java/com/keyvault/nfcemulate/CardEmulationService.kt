package com.keyvault.nfcemulate

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log

/**
 * Host-based Card Emulation (HCE) Service
 * Intercepts ISO 7816-4 APDU commands from contactless RFID/NFC door readers
 * and responds with access token payloads.
 */
class CardEmulationService : HostApduService() {

    companion object {
        private const val TAG = "CardEmulationService"

        // Status Words (ISO 7816-4)
        private val STATUS_SUCCESS = byteArrayOf(0x90.toByte(), 0x00.toByte())
        private val STATUS_FAILED = byteArrayOf(0x6F.toByte(), 0x00.toByte())
        private val CLA_NOT_SUPPORTED = byteArrayOf(0x6E.toByte(), 0x00.toByte())
        private val INS_NOT_SUPPORTED = byteArrayOf(0x6D.toByte(), 0x00.toByte())
        private val FILE_NOT_FOUND = byteArrayOf(0x6A.toByte(), 0x82.toByte())

        // Active Emulation Profile: HQ Tech Campus - Main Gate
        private const val TARGET_AID = "F0010203040506"
        private const val CARD_UID = "7AC39120"
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null || commandApdu.size < 4) {
            return STATUS_FAILED
        }

        val hexCommand = toHex(commandApdu)
        Log.d(TAG, ">>> INCOMING APDU from RFID Reader: $hexCommand")

        // Haptic feedback on tap
        triggerHaptic()

        // 1. SELECT APPLICATION (AID): 00 A4 04 00 [Lc] [AID]
        if (hexCommand.startsWith("00A40400")) {
            Log.d(TAG, "Reader requested SELECT AID: $hexCommand")
            return STATUS_SUCCESS
        }

        // 2. GET CARD UID: 80 CA 00 00 or FF CA 00 00
        if (hexCommand.startsWith("80CA0000") || hexCommand.startsWith("FFCA0000")) {
            Log.d(TAG, "Reader requested Card UID: $CARD_UID")
            val uidBytes = hexStringToByteArray(CARD_UID)
            return concatBytes(uidBytes, STATUS_SUCCESS)
        }

        // 3. READ BINARY / NDEF RECORD: 00 B0
        if (hexCommand.startsWith("00B0")) {
            val payload = "ACCESS_GRANTED_ID_${CARD_UID}".toByteArray(Charsets.UTF_8)
            return concatBytes(payload, STATUS_SUCCESS)
        }

        // Default: Acknowledge with standard ISO 7816-4 SUCCESS
        return STATUS_SUCCESS
    }

    override fun onDeactivated(reason: Int) {
        val reasonStr = when (reason) {
            DEACTIVATION_LINK_LOSS -> "Link Loss (Phone moved away from reader)"
            DEACTIVATION_DESELECTED -> "Deselected by Reader"
            else -> "Unknown ($reason)"
        }
        Log.d(TAG, "NFC RF Field Deactivated: $reasonStr")
    }

    private fun triggerHaptic() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
        vibrator?.let {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(50)
            }
        }
    }

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02X", b))
        }
        return sb.toString()
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val len = s.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(s[i], 16) shl 4) +
                    Character.digit(s[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }

    private fun concatBytes(a: ByteArray, b: ByteArray): ByteArray {
        val result = ByteArray(a.size + b.size)
        System.arraycopy(a, 0, result, 0, a.size)
        System.arraycopy(b, 0, result, a.size, b.size)
        return result
    }
}