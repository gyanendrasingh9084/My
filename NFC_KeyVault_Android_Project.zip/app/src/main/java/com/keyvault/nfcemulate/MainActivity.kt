package com.keyvault.nfcemulate

import android.content.ComponentName
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.cardemulation.CardEmulation
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private var cardEmulation: CardEmulation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        val tvStatus = findViewById<TextView>(R.id.tvNfcStatus)
        val tvCard = findViewById<TextView>(R.id.tvActiveCard)
        val btnSettings = findViewById<Button>(R.id.btnNfcSettings)

        tvCard.text = "HQ Tech Campus - Main Gate (UID: 7A C3 91 20)"

        if (nfcAdapter == null) {
            tvStatus.text = "NFC NOT SUPPORTED: This Android device does not have an NFC chip."
            btnSettings.isEnabled = false
            return
        }

        cardEmulation = CardEmulation.getInstance(nfcAdapter)

        btnSettings.setOnClickListener {
            // Open Android NFC Settings
            startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
        }

        checkNfcStatus(tvStatus)
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.tvNfcStatus)?.let { checkNfcStatus(it) }
    }

    private fun checkNfcStatus(tvStatus: TextView) {
        val adapter = nfcAdapter ?: return
        if (!adapter.isEnabled) {
            tvStatus.text = "NFC IS OFF: Please enable NFC in Android Settings to emulate access cards."
            tvStatus.setTextColor(0xFFFF5252.toInt())
            return
        }

        val component = ComponentName(this, CardEmulationService::class.java)
        val isDefault = cardEmulation?.isDefaultServiceForCategory(component, CardEmulation.CATEGORY_OTHER) ?: false

        if (isDefault) {
            tvStatus.text = "EMULATION READY: Hold phone near door reader."
            tvStatus.setTextColor(0xFF00E676.toInt())
        } else {
            tvStatus.text = "NFC ACTIVE: HCE Service registered and ready."
            tvStatus.setTextColor(0xFF00B0FF.toInt())
        }
    }
}